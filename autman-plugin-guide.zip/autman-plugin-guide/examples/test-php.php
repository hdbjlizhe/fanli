<?php
//[title: test-php]
//[version:1.0.1]
//[disable:false]
//[open_source: true]
//[class: 工具类]
//[service: 282617666]
//[rule: ^test php$]
//[admin: true]
//[description: 仅用于测试php环境，指令：test php，正常的话会回复“php环境正常”]

include 'middleware.php';

// 获取发送者ID
$senderid = $argv[1];
// 打印发送者ID
echo "senderid: ".$senderid."\n";
// 创建sender对象
$sender = new Sender($senderid);
// 获取发送者信息
$chatid=$sender->getChatID();
$chatname=$sender->getChatName();
$userid = $sender->getUserID();
$username = $sender->getUserName();
// 回复消息
$sender->reply("chatid: ".$chatid."\nchatname: ".$chatname."\nuserid: ".$userid."\nusername: ".$username."\n");

$sender->reply("请随意输入一些内容，我会原样返回");
// 打印userid
$input=$sender->listen(60000);
$sender->reply("你输入的内容是：".$input);
?>