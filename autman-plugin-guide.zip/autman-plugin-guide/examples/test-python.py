#[create_at: 2024-11-24 11:09:08]
#[public:true]
#[open_source: true]
#[disable:false]
#[title: test-python]
#[author: hdbjlizhe]
#[version: 1.0.4]
#[price: 0.00]
#[rule: ^test python$]
#[admin: false]
#[service: 282617666]
#[description: 仅用于测试python3环境，指令：test python，会让用户输入一个数字，机器人会回复用户输入的数字。表示python环境正常]

import middleware
import time

def main():
    # 获取发送者ID
    senderID=middleware.getSenderID()
    # 打印到autMan日志，可用于调试
    middleware.printf("测试senderID函数:"+str(senderID))
    # 创建发送者
    sender=middleware.Sender(senderID)
    groupID=sender.getChatID()
    groupName=sender.getChatName()
    userid=sender.getUserID()
    username=sender.getUserName()
    # 回复消息
    sender.reply("你好，"+username+"，你所在的群："+groupName+"，群号："+str(groupID)+"，你的ID："+userid)
    
    bucketSetSuceess= middleware.bucketSet("test","test","test")
    if bucketSetSuceess:
        allkeys=middleware.bucketAllKeys("test")
        testvalue=middleware.bucketGet("test","test")
        success=middleware.bucketDel("test","test")
        keys=middleware.bucketKeys("test","test")
        sender.reply("bucketSet:"+str(bucketSetSuceess)+"\nbucketAllKeys:"+str(allkeys)+"\nBucketGet:"+str(testvalue)+"\nBucketDel:"+str(success)+"\nbucketKeys:"+str(keys))
    else:
        sender.reply("bucketSet失败")
    
    # 发送消息
    sender.reply("请60秒内随意输入一段文字：")
    # 获取消息
    input=sender.listen(60000)
    # 回复消息
    if input==None:
        sender.reply("你输入超时了")
    else:
        sender.reply("你输入的数字是："+input)

    # 获取机器码
    machineCode=middleware.machineId()
    # 通知管理员
    middleware.notifyMasters("机器码是："+machineCode)
    middleware.push(imType="qq",groupCode=None, userID=282617666,title="",content="推送信息："+machineCode)
    # 获取messageid
    msgid=sender.getMessageID()
    middleware.printf("msgid:"+msgid)
    # 撤回消息
    msgid2=sender.reply("测试撤回消息函数recallMessage")
    # 延时
    time.sleep(5)
    sender.reply("即将撤回用户消息")
    sender.recallMessage(msgid)
    time.sleep(5)
    sender.reply("即将撤回机器人消息")
    sender.recallMessage(msgid2)
    
    # 测试支付
    if not sender.atWaitPay():
        sender.reply("开始测试支付函数waitPay\n请60秒内使用微信扫码支付\n[CQ:image,file=https://s3.bmp.ovh/imgs/2022/11/16/af0d40a1e7c5784b.jpg]")
        data=sender.waitPay("q",60000)
        sender.reply("支付结果："+str(data))
    else:
        sender.reply("当前正在有人使用支付，请稍后重试")

if __name__ == '__main__':
    main()