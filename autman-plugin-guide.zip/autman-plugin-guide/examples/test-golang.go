//[title:test-golang] 
//[version:1.0.5]
//[disable:false]
//[open_source:true]
//[description: 指令：test golang，golang插件使用者需要安装golang环境（见云市场插件【golang环境安装】）；golang插件开发者除golang环境外还需要安装中间件，如下安装：ssh进入plugin/scripts文件夹下面，然后输入go get xxx/xxx/xxx]
//[rule: ^test golang$]
//[service:282617666]
package main

import (
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/hdbjlizhe/middleware"
)

func main() {
	//给中间件设置端口号
	port := os.Args[1]     //autMan端口
	senderId := os.Args[2] //发送者id

	fmt.Println("port:", port)
	fmt.Println("senderId:", senderId)
	middleware.Port = port

	//创建对象
	sender := middleware.Sender{
		SenderID: senderId,
	}

	groupCode := sender.GetChatID()
	groupName := sender.GetChatName()
	userID := sender.GetUserID()
	username := sender.GetUsername()

	sender.Reply(fmt.Sprintf("群号：%s\n群名：%s\n用户ID：%s\n用户名：%s", groupCode, groupName, userID, username))

	//等待输入
	sender.Reply("测试输入，请随便输入一些内容：")
	in := sender.Listen(60000)
	if in != "" {
		middleware.NotifyMasters(in, []string{})
		_, err := sender.Reply("您输入的内容是：" + in + "\n以上内容也推送给了管理员\n--------------\n以下测试回复图片")
		fmt.Println(err)
	} else {
		sender.Reply("您没有输入任何内容\n--------------\n以下测试回复图片")
	}

	//回复图片
	ids, err := sender.ReplyImage("https://gitee.com/hdbjlizhe/fanli/raw/main/appreciate.jpg")
	fmt.Println(ids, err)

	//添加计划任务
	c := middleware.Croncmd{
		Cron:           "0 0 * * *",
		Cmd:            "test golang",
		ToSelf:         true,
		DisguiseImtype: "qq",
		DisguiseGroup:  "123",
		DisguiseUser:   "444",
		ToOthers:       "",
		Memo:           "添加测试",
	}
	id, err := middleware.CroncmdsAdd(c)
	fmt.Println(id, err)
	sender.Reply(fmt.Sprintf("添加测试计划任务：%d", id))
	time.Sleep(5 * time.Second)

	//获取计划任务
	c, err = middleware.CroncmdsGetById(id)
	fmt.Println(c, err)
	rlt, _ := json.Marshal(c)
	sender.Reply(fmt.Sprintf("获取测试计划任务：%s", rlt))
	time.Sleep(5 * time.Second)

	//修改计划任务
	c = middleware.Croncmd{
		Id:             id,
		Cron:           "0 0 * * *",
		Cmd:            "test golang",
		ToSelf:         true,
		DisguiseImtype: "qq",
		DisguiseGroup:  "123",
		DisguiseUser:   "444",
		ToOthers:       "",
		Memo:           "测试修改",
	}
	err = middleware.CroncmdsUpd(c)
	fmt.Println(err)
	sender.Reply(fmt.Sprintf("修改测试计划任务：%d", id))
	time.Sleep(5 * time.Second)

	//获取计划任务
	c, err = middleware.CroncmdsGetById(id)
	fmt.Println(c, err)
	rlt, _ = json.Marshal(c)
	sender.Reply(fmt.Sprintf("获取测试计划任务：%s", rlt))
	time.Sleep(5 * time.Second)

	//获取全部计划任务
	cs, err := middleware.CroncmdsGet()
	//回复第一个和最后一个计划任务
	if len(cs) > 0 {
		rlt, _ := json.Marshal(cs[0])
		sender.Reply(fmt.Sprintf("获取全部测试计划任务第一个：%s", rlt))
		rlt, _ = json.Marshal(cs[len(cs)-1])
		sender.Reply(fmt.Sprintf("获取全部测试计划任务最后一个：%s", rlt))
	}
	time.Sleep(5 * time.Second)

	//删除计划任务
	err = middleware.CroncmdsDel(id)
	fmt.Println(err)
	sender.Reply(fmt.Sprintf("删除测试计划任务：%d", id))
}
