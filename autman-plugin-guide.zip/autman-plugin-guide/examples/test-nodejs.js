//[create_at: 2024-01-25 14:06:22]
//[open_source: true]
//[disable:false]
//[title: test-nodejs]
//[create_at: 2023-08-05 15:53:04]
//[author: hdbjlizhe]
//[version: 1.0.4]
//[price: 0.00]
//[rule: ^test nodejs$]
//[admin: true]
//[service: 282617666]
//[description: 仅用于测试自己的nodejs环境，指令：test nodejs，回复nodejs运行正常，表示nodejs环境正常]

// 引入中间件模块
const middleware = require('./middleware.js');
// 获取发送者ID
const senderID = middleware.getSenderID();
// 打印到autMan滚动日志，可用于调试
console.log("senderID:"+senderID)

// 创建发送者
const sender = new middleware.Sender(senderID)

async function main(){
    var name,machineId,version
    var chatid,chatname,userid,username
    // 获取机器人名称
    await middleware.name().then((data)=>{
        console.log(data)
        name=data
    })
    // 获取机器id
    await middleware.machineId().then((data)=>{
        console.log(data)
        machineId=data
    })
    // 获取机器人版本
    await middleware.version().then((data)=>{
        console.log(data)
        version=data.sn
    })

    // 获取发送者id
    await sender.getUserID().then((userID)=>{
        console.log(userID)
        userid=userID
    })
    // 获取发送者名称
    await sender.getUserName().then((userName)=>{
        console.log(userName)
        username=userName
    })
    // 获取群id
    await sender.getChatID().then((chatID)=>{
        console.log(chatID)
        chatid=chatID
    })
    // 获取群名称
    await sender.getGroupName().then((chatName)=>{
        console.log(chatName)
        chatname=chatName
    })
    sender.reply("name:"+name+"\nmachineId:"+machineId+"\nversion:"+version+"\n"+"\nchatid:"+chatid+"\nchatname:"+chatname+"\nuserid:"+userid+"\nusername:"+username)
    
    sender.reply("开始数据库测试...")
    // 数据库测试
    var test
    var msg="设置test为autMan"
    await middleware.set("test","autMan")
    await middleware.get("test").then((data)=>{
        console.log(data)
        test=data
    })
    msg+="\n获取test的值为："+test
    if (test=="autMan"){
        msg+=("\n开始删除测试数据...")
        await middleware.del("test")
        await middleware.get("test").then((data)=>{
            console.log(data)
            test=data
        })
        msg+="\n获取test的值为："+test
        if (!test){
            msg+="\n删除测试数据成功"
        }
    }else {
        msg+="\n数据库测试失败"
    }

    sender.reply(msg+"\n下面开始测试输入...\n---------\n随便输入点什么：")
    // 发送文本消息
    await sender.listen(60000).then((data)=>{
        if (data){
            sender.reply("您输入的消息是："+data)
        }
    })
}

main()