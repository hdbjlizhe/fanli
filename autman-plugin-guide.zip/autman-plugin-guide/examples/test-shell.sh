#[pin:true]
#[public:false]
#[open_source: true]
#[disable:false]
#[title: test-shell]
#[icon:https://bbs.autman.cn/assets/files/2023-12-13/1702432245-790309-bash.png]
#[create_at: 2023-08-05 15:53:17]
#[author: hdbjlizhe]
#[version: 1.0.1]
#[price: 0.00]
#[rule: ^test bash$]
#[admin: true]
#[service: 282617666]
#[description: 仅用于测试bash插件功能，指令:test bash]

# 获取发送者id
senderid=$1
# 引入中间件并构建发送者
source middleware.sh
sender[senderid]=$senderid
# 获取用户id
groupid=$(sender.getChatID)
groupname=$(sender.getGroupName)
userid=$(sender.getUserID)
username=$(sender.getUserName)
# 回复上面的变量
sender.reply "groupid: $groupid\ngroupname: $groupname\nuserid: $userid\nusername: $username"
# 回复消息
sender.reply "bash运行正常"
# 通知管理员
notifyMasters "通知管理员\n运行正常" ""
# 测试push
push "qq" "" "282617666" "标题" "结果"