//[open_source:true]
//[title:test-es5]
//[rule:test es5]
//[author:hdbjlizhe]
//[service:282617666]
//[description:es5插件示例程序]
//[param:{"required":true,"key":"otto.test_push_pt","bool":false,"placeholder":"","name":"推送平台","desc":"推送平台,例如ap、qq、gw等"}]
//[param:{"required":true,"key":"otto.test_push_userid","bool":false,"placeholder":"","name":"推送到","desc":"推送到用户的id"}]
//[param:{"required":true,"key":"otto.test_push_content","bool":false,"placeholder":"","name":"推送内容","desc":"推送内容"}]

//发送当前会话的类型代码
sendText(GetImType())

//测试撤回
id = sendText("测试撤回")
RecallMessage(id)//撤回上面“测试撤回”这句话
RecallMessage(GetMessageID())//撤回用户触发该插件的话

//测试推送
let cnt = bucketGet("otto", "test_push_content")//推送内容
let pt = bucketGet("otto", "test_push_pt")//推送平台
let userid = bucketGet("otto", "test_push_userid")//推送目标
if (!pt || !userid) {
    sendText("配置设置不完整")
} else {
    if (!cnt) {
        cnt = '[测试]你在他xty吗/?？‼️😨✅🤟🏻⭕❌'
    }
    push(
        {
            imType: pt,
            userID: userid,//任意，非空即可，
            content: cnt,
        }
    )
    sendText("app消息已推送，请注意查看")
}

//测试bucketAll函数
Debug("测试bucketAll")
Debug(JSON.stringify(bucketAll("test")))
sendText(JSON.stringify(bucketKeys("autMarketDownloads")))

//测试通知管理员
Debug("测试notifyMasters")
notifyMasters("测试notifyMasters", ["qq"])

//测试推送
Debug("测试push")
push(
    {
        imType: 'qx',
        groupCode: '45557401114@chatroom',
        //groupCode:'4608773869',
        //userID: 'hdbjlizhe',
        userID: 'hdbjlizhe',
        content: '[测试]你在他xty吗/?？‼️😨✅🤟🏻⭕❌',
    }
)
//测试请示函数
option = {
    "method": "get",
    "url": "https://www.ccc.com/"
}
request(option, function (error, response, header, body) {
    Debug(error)
    Debug(response)
    Debug(header)
    Debug(body)
})

//测试等待支付函数
sendText("测试waitPay\n[CQ:image,file=http://ikuai.zhelee.cn:9999/admin/images/gallery/1720765108716383386.jpg]")
pay = waitPay(30000, "q")
//{"Time":"2024-02-01T16:50:05.476042516+08:00","Type":"微信赞赏","FromWxid":"","FromName":"GeeLee","Money":0.01}
Debug(pay)
sendText(JSON.stringify(pay))
sendText("请随便输入点东西：")
msg = input(60000)
sendText("您输入了：" + msg)
//process.exit()

/***********************************
 * 这个是上传base64格式图片，获取url地址，限制5M
 ***********************************/
username = bucketGet("cloud", "username")
password = bucketGet("cloud", "password")
ib = encodeURIComponent("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAXCAIAAACeQxh6AAAAMUlEQVQ4EWP8//8/AzUAEzUMAZkxahDhkBwNo9EwIhwChFWMpqPRMCIcAoRVUC0dAQAx7QMrXoq/sgAAAABJRU5ErkJggg==")
body = request({
    url: "http://aut.zhelee.cn/imgUpload",
    method: "post",
    dataType: "json",
    formData: {
        username: username,
        password: password,
        imgBase64: ib
    },
})
sendText(JSON.stringify(body))

/***********************************
* 这个是上传图片file，获取url地址，限制5M
************************************/
username = bucketGet("cloud", "username")
password = bucketGet("cloud", "password")
body = request({
    url: "http://aut.zhelee.cn/imgUpload",
    method: "post",
    dataType: "json",
    formData: {
        username: username,
        password: password,
    },
    fileData: {
        imgefile: "/root/autMan/xxxx.jpg"
    }
})
sendText(JSON.stringify(body))

//定时指令或定时消息
id = cron.add({//添加定时指令
    cron: "*/5 * * * *",	//定时
    cmd: 'export varient="abc"',	//内容
    toSelf: true,	//定时指令自处理，如果是定时发送消息，此处为false
    toOthers: "qqgroup:123,wxgroup:456,tggroup:789,qqindiv:321,wxindiv:654,tgindiv:987",	//定时消息,如果是定时自处理指令，此处为空
    memo: "备注",
    disguiseImtype: "伪装类型",//值为qq、qb、wx、wb、tg、tb等
    disguiseGroup: "伪装群组ID",
    disguiseUser: "伪装用户ID",
})
sendText("增加的ID:" + id)
result = cron.get(id)//获取序号为id的定时指令，id为number类型
sendText("添加结果：" + JSON.stringify(result))
sleep(10000)
cron.update({//更新定时指令
    id: id,
    cron: "*/5 * * * *",
    cmd: 'export varient="edf"',
    toSelf: true,
    toOthers: "qqgroup:123",
    disguiseImtype: "伪装类型",//值为qq、qb、wx、wb、tg、tb等
    disguiseGroup: "伪装群组ID",
    disguiseUser: "伪装用户ID",
})
result = cron.get(id)//获取序号为id的定时指令，id为number类型
sendText("修改结果：" + JSON.stringify(result))
sleep(10000)
sendText("删除ID：" + id)
cron.delete(id)//删除定时指令
var cs = cron.get()
sendText("第一个结果：" + JSON.stringify(cs[0]))
sendText("最后一个结果：" + JSON.stringify(cs[cs.length - 1]))