---
name: autman-plugin-guide
description: "一份全面的 autMan 平台插件开发指南，用户要提供插件名称、编程语言、功能描述"
---

# 插件开发技能

## 概述

本技能提供了一份完整的 autMan 平台插件开发指南，支持 ECMAScript5、Node.js、Python3、PHP、Shell、Golang 等多种编程语言。通过本指南，你将学习如何编写符合标准的插件，包括头注格式、中间件集成、函数调用等内容。

## 插件内容结构

autMan 平台插件均包括两部分

1. **头注**：插件的元数据信息，用于描述插件的基本属性和配置
2. **本体**：插件的核心功能实现代码

其中的头注包括以下三部分：

1. **市场元数据**（必须）：描述插件的基本信息，如名称、版本、分类等
2. **功能元数据或事件元数据或路由元数据**（必须）：描述插件的功能类型和触发条件
3. **参数元数据**（可选）：描述插件需要用户配置的参数

## 元数据结构

```python
# ---市场元数据---
# [open_source: true/false]           # 是否开源，默认 false
# [icon: url]                         # 图标链接（支持 http/https）
# [version: x.y.z]                    # 语义化版本号，如 1.0.0
# [class: 分类]                       # 自定义插件分类（工具类/查询类/娱乐类等）
# [platform: 平台列表]                # 支持的平台（qq/wx/web 等），多个平台用逗号分隔
# [price: 0.00]                       # 价格（元），默认 0.00
# [service: 联系方式]                 # 技术支持联系方式，如邮箱或微信群
# [description: 描述]                 # 插件功能描述和使用说明，建议详细说明
```

### 市场元数据字段说明

- **open_source**：标记插件是否开源，开源插件可以被其他开发者查看和修改
- **icon**：插件在市场中显示的图标，url格式
- **version**：使用语义化版本号，格式为 x.y.z，其中 x 为主版本号，y 为次版本号，z 为修订号
- **class**：插件分类，帮助用户快速找到所需插件，可自定义分类名称
- **platform**：插件支持的运行平台，多个平台用逗号分隔，如 "qq,wx,web"
- **price**：插件的销售价格，单位为元，免费插件设置为 0.00
- **service**：技术支持联系方式，方便用户在使用过程中遇到问题时联系开发者
- **description**：插件的详细描述，包括功能特点、使用方法、注意事项等

## 事件插件结构

事件插件用于响应特定的系统事件，如用户加入群聊、消息撤回等。

```python
# ---事件元数据---
# [event: 事件名称]                   # 事件名称（可添加多个事件）
```

### 常见事件类型

- **group_join**：用户加入群聊事件
- **group_leave**：用户离开群聊事件
- **message_delete**：消息撤回事件
- **friend_add**：添加好友事件
- **plugin_install**：插件安装事件
- **plugin_uninstall**：插件卸载事件

## 路由插件结构

路由插件用于提供微服务接口，支持 HTTP 请求。

```python
# ---路由元数据---
# [router: /path]                     # 微服务路由路径
# [method: get/post/put/delete]       # HTTP 请求方法
```

## 功能插件结构

功能插件用于处理用户消息，根据关键词触发相应的功能。

```python
# ---功能元数据---
# [rule: 正则表达式]                 # 正则匹配规则，即触发运行的关键词
# [cron: cron表达式]                  # 定时执行的 cron 表达式（可选）
# [admin: true/false]                 # 是否仅管理员可用，默认为false
# [disable: true/false]               # 是否禁用插件，默认为false
# [priority: 0]                       # 插件优先级（数字越大优先级越高）,默认为0
```

### 功能元数据字段说明

- **rule**：正则表达式，用于匹配用户消息，如 "^你好.*" 表示匹配以 "你好" 开头的消息
- **cron**：定时执行的 cron 表达式，如 "0 0 ** *" 表示每天凌晨执行一次
- **admin**：标记插件是否仅管理员可用，管理员可以在平台中配置插件参数
- **disable**：标记插件是否禁用，禁用的插件不会被执行
- **priority**：插件优先级，数字越大优先级越高，当多个插件匹配同一消息时，优先级高的插件先执行

## 参数配置

```python
# ---需要插件用户设置的参数配置---
# [param: {"required":true,"key":"参数名","bool":false,"placeholder":"提示文本","name":"显示名称","desc":"参数描述"}]
# [param: {"spliter":true}]           # 参数分隔线
```

### 参数配置字段说明

- **required**：标记参数是否为必填项，true 表示必填，false 表示可选
- **key**：参数的唯一标识，用于在代码中获取参数值
- **bool**：标记参数是否为布尔类型，true 表示布尔类型，false 表示字符串类型
- **placeholder**：参数输入框的提示文本
- **name**：参数在平台中显示的名称
- **desc**：参数的详细描述，帮助用户理解参数的用途

### 参数配置示例

```python
# ---需要插件用户设置的参数配置---
# [param: {"required":true,"key":"api_key","bool":false,"placeholder":"请输入 API 密钥","name":"API 密钥","desc":"第三方服务的 API 密钥"}]
# [param: {"spliter":true}]
# [param: {"required":false,"key":"timeout","bool":false,"placeholder":"30","name":"超时时间","desc":"请求超时时间（秒）"}]
```

## 中间件集成

中间件提供了一些通用的功能函数，插件可以直接调用这些函数，无需重复实现。

### Node.js

```javascript
const middleware = require('./middleware.js');
```

### Python3

```python
import middleware
```

### PHP

```php
include 'middleware.php';
```

### Go

```go
import "github.com/hdbjlizhe/middleware"
```

### Shell

```bash
source middleware.sh
```

### ES5

无需引入中间件

## 函数调用

### 通用规则

1. 所有中间件内定义的函数在插件主体中均可直接调用
2. 要优先调用中间件内的函数，不要重复写与中间件相同功能的函数
3. 调用函数时，参数格式要符合函数的要求

### 中间件内容

#### ES5插件中间件函数

使用read_file工具读取plugin/replies/middleware.jsx来查看插件可直接调用的函数

#### Python插件中间件

使用read_file工具读取plugin/scripts/middleware.py来查看插件可直接调用的函数

#### Nodejs插件中间件

使用read_file工具读取plugin/scripts/middleware.js来查看插件可直接调用的函数

#### Php插件中间件

使用read_file工具读取plugin/scripts/middleware.php来查看插件可直接调用的函数

#### Golang插件中间件

使用read_file工具读取plugin/scripts/middleware/middleware.go来查看插件可直接调用的函数

#### Shell插件中间件

使用read_file工具读取plugin/scripts/middleware/middleware.sh来查看插件可直接调用的函数

## 代码示例

### ES5 插件 (test-es5.js)

使用read_file工具读取skills/autman-plugin-guide/examples/test-es5.js文件内容作为代码示例

### Python3 示例

使用read_file工具读取skills/autman-plugin-guide/examples/test-python.py文件内容作为代码示例

### Node.js 示例

使用read_file工具读取skills/autman-plugin-guide/examples/test-nodejs.js文件内容作为代码示例

### Php 示例

使用read_file工具读取skills/autman-plugin-guide/examples/test-php.php文件内容作为代码示例

### Golang示例

使用read_file工具读取skills/autman-plugin-guide/examples/test-golang.go文件内容作为代码示例

### Bash示例

使用read_file工具读取skills/autman-plugin-guide/examples/test-shell.go文件内容作为代码示例

## 部署流程

1. 按照标准编写插件代码
2. 按照示例代码修改插件代码
3. 使用write_file工具将插件代码保存到插件目录，ES5插件目录为plugin/replies/，其他插件目录为plugin/scripts

## 更新日志

- 版本 1.0.0：初始发布

## 技术支持

如有问题或建议，请联系 <282617666@qq.com> 或访问 autMan 论坛留言
